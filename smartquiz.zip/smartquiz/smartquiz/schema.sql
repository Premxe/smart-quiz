PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS attempts;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS quizzes;
DROP TABLE IF EXISTS users;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student'
        CHECK (role IN ('student', 'admin', 'instructor'))
);

CREATE TABLE IF NOT EXISTS quizzes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL CHECK (LENGTH(TRIM(title)) > 0),
    created_by INTEGER NOT NULL,
    FOREIGN KEY (created_by) REFERENCES users (id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id INTEGER NOT NULL,
    question TEXT NOT NULL CHECK (LENGTH(TRIM(question)) > 0),
    option1 TEXT NOT NULL CHECK (LENGTH(TRIM(option1)) > 0),
    option2 TEXT NOT NULL CHECK (LENGTH(TRIM(option2)) > 0),
    option3 TEXT NOT NULL CHECK (LENGTH(TRIM(option3)) > 0),
    option4 TEXT NOT NULL CHECK (LENGTH(TRIM(option4)) > 0),
    correct_answer INTEGER NOT NULL CHECK (correct_answer BETWEEN 1 AND 4),
    FOREIGN KEY (quiz_id) REFERENCES quizzes (id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    quiz_id INTEGER NOT NULL,
    score INTEGER NOT NULL CHECK (score >= 0),
    timestamp TEXT NOT NULL DEFAULT (DATETIME('now')),
    FOREIGN KEY (user_id) REFERENCES users (id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    FOREIGN KEY (quiz_id) REFERENCES quizzes (id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_quizzes_created_by ON quizzes (created_by);
CREATE INDEX IF NOT EXISTS idx_questions_quiz_id ON questions (quiz_id);
CREATE INDEX IF NOT EXISTS idx_attempts_user_id ON attempts (user_id);
CREATE INDEX IF NOT EXISTS idx_attempts_quiz_id ON attempts (quiz_id);
CREATE INDEX IF NOT EXISTS idx_attempts_timestamp ON attempts (timestamp);
