from __future__ import annotations

import os
import sqlite3
from functools import wraps
from pathlib import Path
from typing import Callable

import click
from flask import (
    Flask,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash


BASE_DIR = Path(__file__).resolve().parent


def create_app() -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-in-production")

    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    app.config["DATABASE"] = str(Path(app.instance_path) / "quiz.db")

    register_lifecycle_handlers(app)
    register_error_handlers(app)
    register_cli_commands(app)
    register_routes(app)

    with app.app_context():
        init_db()

    return app


def register_lifecycle_handlers(app: Flask) -> None:
    @app.teardown_appcontext
    def close_db(_: object) -> None:
        db = g.pop("db", None)
        if db is not None:
            db.close()


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        db_path = current_app.config["DATABASE"]
        g.db = sqlite3.connect(db_path, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def init_db(force: bool = False) -> bool:
    db_path = Path(current_app.config["DATABASE"])
    if db_path.exists() and not force:
        return False

    db = get_db()
    schema_path = BASE_DIR / "schema.sql"
    try:
        with schema_path.open("r", encoding="utf-8") as schema_file:
            db.executescript(schema_file.read())
        db.commit()
        return True
    except sqlite3.Error:
        db.rollback()
        raise

def register_cli_commands(app: Flask) -> None:
    @app.cli.command("init-db")
    @click.option("--force", is_flag=True, help="Recreate database using schema.sql")
    def init_db_command(force: bool) -> None:
        created = init_db(force=force)
        if created:
            click.echo("Database initialized from schema.sql")
        else:
            click.echo("Database already exists. Use --force to recreate it.")


def register_error_handlers(app: Flask) -> None:
    @app.errorhandler(404)
    def not_found(_: object):
        return render_template("404.html"), 404


def login_required(view: Callable) -> Callable:
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def admin_required(view: Callable) -> Callable:
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))

        if session.get("role") != "instructor":
            flash("Instructor access is required.", "danger")
            return redirect(url_for("login"))

        return view(*args, **kwargs)

    return wrapped


def evaluate_quiz_submission(form_data, questions: list[sqlite3.Row]) -> tuple[int, int]:
    score = 0
    answered_count = 0

    for question in questions:
        raw_value = form_data.get(f"question_{question['id']}", "")
        if raw_value is None:
            continue

        selected_value = raw_value.strip()
        if not selected_value.isdigit():
            # Missing or malformed input is treated as unanswered.
            continue

        selected_option = int(selected_value)
        if selected_option not in {1, 2, 3, 4}:
            continue

        answered_count += 1
        if selected_option == question["correct_answer"]:
            score += 1

    return score, answered_count


def validate_question_payload(
    question_text: str,
    option1: str,
    option2: str,
    option3: str,
    option4: str,
    correct_answer_raw: str,
) -> tuple[bool, str | None, int | None]:
    options = [option1.strip(), option2.strip(), option3.strip(), option4.strip()]

    if not question_text.strip():
        return False, "Question text is required.", None

    if any(not option for option in options):
        return False, "All four options are required.", None

    if not correct_answer_raw.strip().isdigit():
        return False, "Correct answer must be one of the four options.", None

    correct_answer = int(correct_answer_raw.strip())
    if correct_answer not in {1, 2, 3, 4}:
        return False, "Correct answer must be one of the four options.", None

    if not options[correct_answer - 1]:
        return False, "Correct answer must match one of the provided options.", None

    return True, None, correct_answer


def register_routes(app: Flask) -> None:
    @app.route("/")
    def index():
        try:
            quizzes = get_db().execute(
                """
                SELECT id, title, '' AS description
                FROM quizzes
                ORDER BY id DESC
                """
            ).fetchall()
            return render_template("index.html", quizzes=quizzes)
        except sqlite3.Error:
            flash("We could not load quizzes right now. Please try again later.", "danger")
            return render_template("index.html", quizzes=[])

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            role = request.form.get("role", "student").strip().lower()
            allowed_roles = {"student", "instructor"}

            if not username or not password or not role:
                flash("Username, password, and role are required.", "danger")
                return render_template("register.html")

            if len(username) < 3:
                flash("Username must be at least 3 characters long.", "danger")
                return render_template("register.html")

            if len(password) < 8:
                flash("Password must be at least 8 characters long.", "danger")
                return render_template("register.html")

            if role not in allowed_roles:
                flash("Invalid role selected.", "danger")
                return render_template("register.html")

            db = get_db()
            duplicate = db.execute(
                "SELECT 1 FROM users WHERE username = ?",
                (username,),
            ).fetchone()
            if duplicate:
                flash("Username is already taken.", "danger")
                return render_template("register.html")

            try:
                db.execute(
                    "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                    (username, generate_password_hash(password), role),
                )
                db.commit()
            except sqlite3.IntegrityError:
                db.rollback()
                flash("Unable to register user due to a data constraint violation.", "danger")
                return render_template("register.html")

            flash("Account created successfully. Please log in.", "success")
            return redirect(url_for("login"))

        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")

            user = get_db().execute(
                "SELECT id, username, password_hash, role FROM users WHERE username = ?",
                (username,),
            ).fetchone()

            if user is None or not check_password_hash(user["password_hash"], password):
                flash("Invalid username or password.", "danger")
                return render_template("login.html")

            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["is_admin"] = user["role"] == "instructor"

            flash("Login successful.", "success")
            if user["role"] == "instructor":
                return redirect(url_for("admin"))

            return redirect(url_for("dashboard"))

        return render_template("login.html")

    @app.route("/logout")
    def logout():
        session.clear()
        flash("Logged out successfully.", "info")
        return redirect(url_for("index"))

    @app.route("/dashboard")
    @login_required
    def dashboard():
        try:
            db = get_db()
            quizzes = db.execute(
                """
                SELECT id, title, '' AS description
                FROM quizzes
                ORDER BY id DESC
                """
            ).fetchall()

            attempts = db.execute(
                """
                SELECT
                    a.id,
                    q.title,
                    a.score,
                    COALESCE(qc.total_questions, 0) AS total_questions,
                    a.timestamp AS completed_at
                FROM attempts a
                JOIN quizzes q ON q.id = a.quiz_id
                LEFT JOIN (
                    SELECT quiz_id, COUNT(*) AS total_questions
                    FROM questions
                    GROUP BY quiz_id
                ) qc ON qc.quiz_id = q.id
                WHERE a.user_id = ?
                ORDER BY a.timestamp DESC
                LIMIT 10
                """,
                (session["user_id"],),
            ).fetchall()

            performance_points = db.execute(
                """
                SELECT
                    DATE(a.timestamp) AS day,
                    AVG(CASE
                        WHEN qc.total_questions > 0 THEN (a.score * 100.0) / qc.total_questions
                        ELSE 0
                    END) AS avg_percentage
                FROM attempts a
                LEFT JOIN (
                    SELECT quiz_id, COUNT(*) AS total_questions
                    FROM questions
                    GROUP BY quiz_id
                ) qc ON qc.quiz_id = a.quiz_id
                WHERE a.user_id = ?
                GROUP BY DATE(a.timestamp)
                ORDER BY day DESC
                LIMIT 7
                """,
                (session["user_id"],),
            ).fetchall()

            activity_points = db.execute(
                """
                SELECT
                    DATE(timestamp) AS day,
                    COUNT(*) AS attempts_count
                FROM attempts
                WHERE user_id = ?
                GROUP BY DATE(timestamp)
                ORDER BY day DESC
                LIMIT 7
                """,
                (session["user_id"],),
            ).fetchall()

            performance_points = list(reversed(performance_points))
            activity_points = list(reversed(activity_points))

            chart_labels = [point["day"] for point in performance_points] or [point["day"] for point in activity_points]
            performance_values = [round(float(point["avg_percentage"] or 0), 1) for point in performance_points]

            activity_map = {point["day"]: int(point["attempts_count"] or 0) for point in activity_points}
            activity_values = [activity_map.get(day, 0) for day in chart_labels]

            return render_template(
                "dashboard.html",
                quizzes=quizzes,
                attempts=attempts,
                chart_labels=chart_labels,
                performance_values=performance_values,
                activity_values=activity_values,
            )
        except sqlite3.Error:
            flash("We could not load your dashboard right now. Please try again later.", "danger")
            return render_template(
                "dashboard.html",
                quizzes=[],
                attempts=[],
                chart_labels=[],
                performance_values=[],
                activity_values=[],
            )

    @app.route("/leaderboard")
    def leaderboard():
        try:
            leaders = get_db().execute(
                """
                SELECT
                    u.username,
                    a.score,
                    q.title AS quiz_title,
                    a.timestamp
                FROM attempts a
                JOIN users u ON u.id = a.user_id
                JOIN quizzes q ON q.id = a.quiz_id
                ORDER BY a.score DESC, a.timestamp ASC
                LIMIT 20
                """
            ).fetchall()

            return render_template("leaderboard.html", leaders=leaders)
        except sqlite3.Error:
            flash("We could not load the leaderboard right now.", "danger")
            return render_template("leaderboard.html", leaders=[])

    @app.route("/quiz")
    @login_required
    def quiz_list_redirect():
        flash("Select a quiz from your dashboard.", "info")
        return redirect(url_for("dashboard"))

    @app.route("/quiz/<int:quiz_id>")
    @login_required
    def quiz(quiz_id: int):
        try:
            db = get_db()
            quiz_row = db.execute(
                "SELECT id, title, '' AS description FROM quizzes WHERE id = ?",
                (quiz_id,),
            ).fetchone()

            if quiz_row is None:
                flash("Quiz not found.", "warning")
                return redirect(url_for("dashboard"))

            questions = db.execute(
                """
                SELECT id, question AS question_text, option1, option2, option3, option4, correct_answer
                FROM questions
                WHERE quiz_id = ?
                ORDER BY id ASC
                """,
                (quiz_id,),
            ).fetchall()
        except sqlite3.Error:
            flash("We could not load this quiz right now.", "danger")
            return redirect(url_for("dashboard"))

        options_map: dict[int, list[dict[str, object]]] = {}
        for q in questions:
            options_map[q["id"]] = [
                {"value": 1, "option_text": q["option1"]},
                {"value": 2, "option_text": q["option2"]},
                {"value": 3, "option_text": q["option3"]},
                {"value": 4, "option_text": q["option4"]},
            ]

        return render_template("quiz.html", quiz=quiz_row, questions=questions, options_map=options_map)

    @app.route("/submit_quiz/<int:quiz_id>", methods=["POST"])
    @login_required
    def submit_quiz(quiz_id: int):
        db = get_db()

        try:
            questions = db.execute(
                """
                SELECT id, correct_answer
                FROM questions
                WHERE quiz_id = ?
                ORDER BY id ASC
                """,
                (quiz_id,),
            ).fetchall()
        except sqlite3.Error:
            flash("Unable to load quiz answers right now.", "danger")
            return redirect(url_for("quiz", quiz_id=quiz_id))

        if not questions:
            flash("This quiz has no questions yet.", "warning")
            return redirect(url_for("dashboard"))

        score, answered_count = evaluate_quiz_submission(request.form, questions)

        try:
            cursor = db.execute(
                "INSERT INTO attempts (user_id, quiz_id, score) VALUES (?, ?, ?)",
                (session["user_id"], quiz_id, score),
            )
            db.commit()
        except sqlite3.Error:
            db.rollback()
            flash("Failed to submit quiz. Please try again.", "danger")
            return redirect(url_for("quiz", quiz_id=quiz_id))

        flash(
            f"Quiz submitted. Your score is {score}/{len(questions)} (answered {answered_count}).",
            "success",
        )
        return redirect(url_for("result", attempt_id=cursor.lastrowid))

    @app.route("/result/<int:attempt_id>")
    @login_required
    def result(attempt_id: int):
        try:
            attempt = get_db().execute(
                """
                SELECT
                    a.id,
                    q.title,
                    a.score,
                    a.timestamp AS completed_at,
                    COALESCE(qc.total_questions, 0) AS total_questions
                FROM attempts a
                JOIN quizzes q ON q.id = a.quiz_id
                LEFT JOIN (
                    SELECT quiz_id, COUNT(*) AS total_questions
                    FROM questions
                    GROUP BY quiz_id
                ) qc ON qc.quiz_id = q.id
                WHERE a.id = ? AND a.user_id = ?
                """,
                (attempt_id, session["user_id"]),
            ).fetchone()

            if attempt is None:
                flash("Result not found.", "warning")
                return redirect(url_for("dashboard"))

            total_questions = int(attempt["total_questions"] or 0)
            correct_answers = int(attempt["score"] or 0)
            percentage = (correct_answers / total_questions * 100) if total_questions else 0
            feedback_message = "Good job" if percentage >= 60 else "Try again"

            return render_template(
                "result.html",
                attempt=attempt,
                correct_answers=correct_answers,
                feedback_message=feedback_message,
            )
        except sqlite3.Error:
            flash("We could not load this result right now.", "danger")
            return redirect(url_for("dashboard"))

    @app.route("/admin", methods=["GET", "POST"])
    @admin_required
    def admin():
        db = get_db()

        if request.method == "POST":
            title = request.form.get("title", "").strip()

            if not title:
                flash("Quiz title is required.", "danger")
                return redirect(url_for("admin"))

            try:
                db.execute(
                    "INSERT INTO quizzes (title, created_by) VALUES (?, ?)",
                    (title, session["user_id"]),
                )
                db.commit()
                flash("Quiz created successfully.", "success")
            except sqlite3.IntegrityError:
                db.rollback()
                flash("Unable to create quiz due to invalid data.", "danger")

            return redirect(url_for("admin"))

        quizzes = db.execute(
            """
            SELECT q.id, q.title, u.username AS created_by_username
            FROM quizzes q
            JOIN users u ON u.id = q.created_by
            ORDER BY q.id DESC
            """
        ).fetchall()

        total_students_row = db.execute(
            "SELECT COUNT(*) AS total_students FROM users WHERE role = 'student'"
        ).fetchone()
        total_attempts_row = db.execute("SELECT COUNT(*) AS total_attempts FROM attempts").fetchone()
        total_quizzes_row = db.execute("SELECT COUNT(*) AS total_quizzes FROM quizzes").fetchone()

        performance_row = db.execute(
            """
            SELECT
                AVG(CASE
                    WHEN qc.total_questions > 0 THEN (a.score * 100.0) / qc.total_questions
                    ELSE 0
                END) AS avg_performance
            FROM attempts a
            LEFT JOIN (
                SELECT quiz_id, COUNT(*) AS total_questions
                FROM questions
                GROUP BY quiz_id
            ) qc ON qc.quiz_id = a.quiz_id
            """
        ).fetchone()

        performance_points = db.execute(
            """
            SELECT
                DATE(a.timestamp) AS day,
                AVG(CASE
                    WHEN qc.total_questions > 0 THEN (a.score * 100.0) / qc.total_questions
                    ELSE 0
                END) AS avg_percentage
            FROM attempts a
            LEFT JOIN (
                SELECT quiz_id, COUNT(*) AS total_questions
                FROM questions
                GROUP BY quiz_id
            ) qc ON qc.quiz_id = a.quiz_id
            GROUP BY DATE(a.timestamp)
            ORDER BY day DESC
            LIMIT 7
            """
        ).fetchall()

        participation_points = db.execute(
            """
            SELECT
                DATE(timestamp) AS day,
                COUNT(*) AS total_participation
            FROM attempts
            GROUP BY DATE(timestamp)
            ORDER BY day DESC
            LIMIT 7
            """
        ).fetchall()

        performance_points = list(reversed(performance_points))
        participation_points = list(reversed(participation_points))

        chart_labels = [point["day"] for point in performance_points] or [point["day"] for point in participation_points]
        performance_values = [round(float(point["avg_percentage"] or 0), 1) for point in performance_points]

        participation_map = {point["day"]: int(point["total_participation"] or 0) for point in participation_points}
        participation_values = [participation_map.get(day, 0) for day in chart_labels]

        return render_template(
            "admin.html",
            quizzes=quizzes,
            stats={
                "total_students": int(total_students_row["total_students"] or 0),
                "total_quizzes": int(total_quizzes_row["total_quizzes"] or 0),
                "total_attempts": int(total_attempts_row["total_attempts"] or 0),
                "performance": round(float(performance_row["avg_performance"] or 0), 1),
            },
            chart_labels=chart_labels,
            performance_values=performance_values,
            participation_values=participation_values,
        )

    @app.route("/admin/quizzes")
    @admin_required
    def admin_quizzes():
        try:
            quizzes = get_db().execute(
                """
                SELECT q.id, q.title, u.username AS created_by_username
                FROM quizzes q
                JOIN users u ON u.id = q.created_by
                ORDER BY q.id DESC
                """
            ).fetchall()
        except sqlite3.Error:
            flash("Unable to load quizzes right now.", "danger")
            quizzes = []

        return render_template("admin_quizzes.html", quizzes=quizzes)

    @app.route("/admin/create_quiz", methods=["GET", "POST"])
    @admin_required
    def create_quiz():
        if request.method == "POST":
            title = request.form.get("title", "").strip()

            if not title:
                flash("Quiz title is required.", "danger")
                return render_template("create_quiz.html")

            try:
                db = get_db()
                cursor = db.execute(
                    "INSERT INTO quizzes (title, created_by) VALUES (?, ?)",
                    (title, session["user_id"]),
                )
                db.commit()
            except sqlite3.IntegrityError:
                db.rollback()
                flash("Unable to create quiz due to invalid data.", "danger")
                return render_template("create_quiz.html")
            except sqlite3.Error:
                db.rollback()
                flash("Database error while creating quiz.", "danger")
                return render_template("create_quiz.html")

            flash("Quiz created successfully. Add questions next.", "success")
            return redirect(url_for("add_question", quiz_id=cursor.lastrowid))

        return render_template("create_quiz.html")

    @app.route("/admin/add_question/<int:quiz_id>", methods=["GET", "POST"])
    @admin_required
    def add_question(quiz_id: int):
        db = get_db()
        quiz = db.execute(
            "SELECT id, title FROM quizzes WHERE id = ?",
            (quiz_id,),
        ).fetchone()

        if quiz is None:
            flash("Quiz not found.", "warning")
            return redirect(url_for("admin"))

        if request.method == "POST":
            question_text = request.form.get("question", "").strip()
            option1 = request.form.get("option1", "").strip()
            option2 = request.form.get("option2", "").strip()
            option3 = request.form.get("option3", "").strip()
            option4 = request.form.get("option4", "").strip()
            correct_answer_raw = request.form.get("correct_answer", "").strip()

            is_valid, error_message, correct_answer = validate_question_payload(
                question_text,
                option1,
                option2,
                option3,
                option4,
                correct_answer_raw,
            )

            if not is_valid:
                flash(error_message or "Invalid question data.", "danger")
                return redirect(url_for("add_question", quiz_id=quiz_id))

            try:
                db.execute(
                    """
                    INSERT INTO questions
                        (quiz_id, question, option1, option2, option3, option4, correct_answer)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        quiz_id,
                        question_text,
                        option1,
                        option2,
                        option3,
                        option4,
                        correct_answer,
                    ),
                )
                db.commit()
                flash("Question added successfully. You can add another one.", "success")
            except sqlite3.IntegrityError:
                db.rollback()
                flash("Invalid question data. Question was not saved.", "danger")
            except sqlite3.Error:
                db.rollback()
                flash("Failed to add question.", "danger")

            return redirect(url_for("add_question", quiz_id=quiz_id))

        questions = db.execute(
            """
            SELECT id, question, option1, option2, option3, option4, correct_answer
            FROM questions
            WHERE quiz_id = ?
            ORDER BY id DESC
            """,
            (quiz_id,),
        ).fetchall()

        return render_template("add_question.html", quiz=quiz, questions=questions)

    @app.route("/admin/quizzes/<int:quiz_id>/delete", methods=["POST"])
    @admin_required
    def delete_quiz(quiz_id: int):
        db = get_db()

        quiz = db.execute("SELECT id FROM quizzes WHERE id = ?", (quiz_id,)).fetchone()
        if quiz is None:
            flash("Quiz not found.", "warning")
            return redirect(url_for("admin"))

        try:
            db.execute("DELETE FROM quizzes WHERE id = ?", (quiz_id,))
            db.commit()
            flash("Quiz deleted successfully.", "success")
        except sqlite3.Error:
            db.rollback()
            flash("Failed to delete quiz.", "danger")

        return redirect(url_for("admin_quizzes"))

    @app.route("/admin/quizzes/<int:quiz_id>/questions", methods=["GET", "POST"])
    @admin_required
    def manage_quiz_questions(quiz_id: int):
        return redirect(url_for("add_question", quiz_id=quiz_id))


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
