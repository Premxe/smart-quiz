document.addEventListener("DOMContentLoaded", () => {
    const quizForm = document.getElementById("quiz-form");
    const timerElement = document.getElementById("quiz-timer");
    const adminLayout = document.getElementById("adminLayout");
    const adminSidebar = document.getElementById("adminSidebar");
    const sidebarToggle = document.getElementById("sidebarToggle");
    const performanceCanvas = document.getElementById("performanceChart");
    const participationCanvas = document.getElementById("participationChart");
    const userPerformanceCanvas = document.getElementById("userPerformanceChart");
    const userActivityCanvas = document.getElementById("userActivityChart");

    let autoSubmitting = false;
    let isSubmitting = false;

    const submitButton = quizForm ? quizForm.querySelector('button[type="submit"]') : null;

    const formatTime = (totalSeconds) => {
        const minutes = Math.floor(totalSeconds / 60)
            .toString()
            .padStart(2, "0");
        const seconds = (totalSeconds % 60).toString().padStart(2, "0");
        return `${minutes}:${seconds}`;
    };

    const updateSelectedOptionStyles = () => {
        if (!quizForm) {
            return;
        }

        const radioInputs = quizForm.querySelectorAll('input.form-check-input[type="radio"]');
        radioInputs.forEach((input) => {
            const optionRow = input.closest(".form-check");
            if (!optionRow) {
                return;
            }

            if (input.checked) {
                optionRow.classList.add("quiz-option-selected");
            } else {
                optionRow.classList.remove("quiz-option-selected");
            }
        });
    };

    if (quizForm) {
        quizForm.addEventListener("change", (event) => {
            const target = event.target;
            if (!(target instanceof HTMLInputElement)) {
                return;
            }

            if (target.matches('input.form-check-input[type="radio"]')) {
                updateSelectedOptionStyles();
            }
        });
        updateSelectedOptionStyles();
    }

    if (quizForm && timerElement) {
        let remainingSeconds = parseInt(timerElement.dataset.timeLimit || "300", 10);
        if (Number.isNaN(remainingSeconds) || remainingSeconds <= 0) {
            remainingSeconds = 300;
        }

        timerElement.textContent = formatTime(remainingSeconds);

        const timerInterval = window.setInterval(() => {
            remainingSeconds -= 1;
            timerElement.textContent = formatTime(Math.max(remainingSeconds, 0));

            if (remainingSeconds <= 60) {
                timerElement.classList.add("text-danger");
            }

            if (remainingSeconds <= 0) {
                window.clearInterval(timerInterval);
                autoSubmitting = true;
                quizForm.requestSubmit();
            }
        }, 1000);
    }

    if (quizForm) {
        quizForm.addEventListener("submit", (event) => {
            if (isSubmitting) {
                event.preventDefault();
                return;
            }

            if (autoSubmitting) {
                isSubmitting = true;
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.textContent = "Submitting...";
                }
                return;
            }

            const confirmed = window.confirm("Submit quiz now? You will not be able to edit answers.");
            if (!confirmed) {
                event.preventDefault();
                return;
            }

            isSubmitting = true;
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = "Submitting...";
            }
        });
    }

    if (adminLayout && adminSidebar && sidebarToggle) {
        const desktopMediaQuery = window.matchMedia("(min-width: 1200px)");
        const collapsedKey = "sqSidebarCollapsed";

        const syncSidebarMode = () => {
            if (desktopMediaQuery.matches) {
                adminSidebar.classList.remove("open");
                const shouldCollapse = window.localStorage.getItem(collapsedKey) === "1";
                adminLayout.classList.toggle("sq-sidebar-collapsed", shouldCollapse);
            } else {
                adminLayout.classList.remove("sq-sidebar-collapsed");
            }
        };

        sidebarToggle.addEventListener("click", () => {
            if (desktopMediaQuery.matches) {
                const isCollapsed = adminLayout.classList.toggle("sq-sidebar-collapsed");
                window.localStorage.setItem(collapsedKey, isCollapsed ? "1" : "0");
            } else {
                adminSidebar.classList.toggle("open");
            }
        });

        desktopMediaQuery.addEventListener("change", syncSidebarMode);
        syncSidebarMode();
    }

    if (performanceCanvas && participationCanvas && typeof window.Chart !== "undefined") {
        const labelsElement = document.getElementById("admin-chart-labels");
        const performanceElement = document.getElementById("admin-chart-performance");
        const participationElement = document.getElementById("admin-chart-participation");

        const labels = labelsElement ? JSON.parse(labelsElement.textContent || "[]") : [];
        const performanceValues = performanceElement ? JSON.parse(performanceElement.textContent || "[]") : [];
        const participationValues = participationElement ? JSON.parse(participationElement.textContent || "[]") : [];

        const chartCommonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: "#cbd5e1",
                    },
                },
            },
            scales: {
                x: {
                    ticks: { color: "#94a3b8" },
                    grid: { color: "rgba(148, 163, 184, 0.2)" },
                },
                y: {
                    ticks: { color: "#94a3b8" },
                    grid: { color: "rgba(148, 163, 184, 0.2)" },
                    beginAtZero: true,
                },
            },
        };

        new window.Chart(performanceCanvas.getContext("2d"), {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label: "Performance %",
                        data: performanceValues,
                        borderColor: "#38bdf8",
                        backgroundColor: "rgba(56, 189, 248, 0.18)",
                        borderWidth: 3,
                        pointRadius: 3,
                        pointBackgroundColor: "#7dd3fc",
                        tension: 0.35,
                        fill: false,
                    },
                ],
            },
            options: chartCommonOptions,
        });

        new window.Chart(participationCanvas.getContext("2d"), {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label: "Participation",
                        data: participationValues,
                        borderColor: "#22c55e",
                        backgroundColor: "rgba(34, 197, 94, 0.22)",
                        borderWidth: 3,
                        pointRadius: 2,
                        pointHoverRadius: 4,
                        tension: 0.35,
                        fill: true,
                    },
                ],
            },
            options: chartCommonOptions,
        });
    }

    if (userPerformanceCanvas && userActivityCanvas && typeof window.Chart !== "undefined") {
        const labelsElement = document.getElementById("user-chart-labels");
        const performanceElement = document.getElementById("user-chart-performance");
        const activityElement = document.getElementById("user-chart-activity");

        const labels = labelsElement ? JSON.parse(labelsElement.textContent || "[]") : [];
        const performanceValues = performanceElement ? JSON.parse(performanceElement.textContent || "[]") : [];
        const activityValues = activityElement ? JSON.parse(activityElement.textContent || "[]") : [];

        const chartCommonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 1000,
                easing: "easeOutQuart",
            },
            plugins: {
                legend: {
                    labels: {
                        color: "#cbd5e1",
                    },
                },
                tooltip: {
                    backgroundColor: "rgba(15, 23, 42, 0.92)",
                    titleColor: "#f8fafc",
                    bodyColor: "#e2e8f0",
                    borderColor: "rgba(148, 163, 184, 0.35)",
                    borderWidth: 1,
                },
            },
            scales: {
                x: {
                    ticks: { color: "#94a3b8" },
                    grid: { color: "rgba(148, 163, 184, 0.18)" },
                },
                y: {
                    ticks: { color: "#94a3b8" },
                    grid: { color: "rgba(148, 163, 184, 0.18)" },
                    beginAtZero: true,
                },
            },
        };

        new window.Chart(userPerformanceCanvas.getContext("2d"), {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label: "Performance %",
                        data: performanceValues,
                        borderColor: "#38bdf8",
                        backgroundColor: "rgba(56, 189, 248, 0.15)",
                        borderWidth: 3,
                        pointRadius: 3,
                        pointHoverRadius: 5,
                        pointBackgroundColor: "#7dd3fc",
                        tension: 0.35,
                        fill: false,
                    },
                ],
            },
            options: chartCommonOptions,
        });

        new window.Chart(userActivityCanvas.getContext("2d"), {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label: "Activity",
                        data: activityValues,
                        borderColor: "#22c55e",
                        backgroundColor: "rgba(34, 197, 94, 0.22)",
                        borderWidth: 3,
                        pointRadius: 2,
                        pointHoverRadius: 4,
                        tension: 0.35,
                        fill: true,
                    },
                ],
            },
            options: chartCommonOptions,
        });
    }
});
