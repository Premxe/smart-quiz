# Online Quiz System (Flask)

A starter Online Quiz System built with Flask, SQLite, HTML, CSS, and JavaScript.

## Tech Stack
- Flask
- SQLite
- Jinja2 templates
- Vanilla CSS and JavaScript

## Project Structure

```
smartquiz/
|-- app.py
|-- schema.sql
|-- requirements.txt
|-- .gitignore
|-- README.md
|-- instance/
|   `-- .gitkeep
|-- static/
|   |-- css/
|   |   `-- styles.css
|   `-- js/
|       `-- main.js
`-- templates/
    |-- base.html
    |-- index.html
    |-- login.html
    |-- register.html
    |-- dashboard.html
    |-- quiz.html
    |-- result.html
    `-- admin.html
```

## Setup

1. Create and activate a virtual environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   flask --app app run --debug
   ```

On first run, the app initializes the database automatically and seeds sample data.

## Default Admin Account
- Username: admin
- Password: admin123

Use this account to access the admin panel at `/admin`.
